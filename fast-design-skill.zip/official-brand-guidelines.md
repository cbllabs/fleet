# FAST Official Brand Guidelines

Source of truth: the FAST Media Kit and `Fast-BrandGuidelines.pdf`.

Use this file first when a FAST surface needs brand direction. If this file conflicts with older FAST demos, pitch decks, or shipped UI tokens, use this file for brand primitives and use shipped FAST surfaces only for interaction patterns.

## Core brand idea

FAST should feel like:
- solid infrastructure in fluid motion
- speed without aggression
- flow without chaos
- machine value exchange in motion

That means calm precision, controlled contrast, and motion that feels engineered instead of flashy.

## Official palette

| Name | Hex | Role |
| --- | --- | --- |
| Platinum | `#F6F8FA` | Primary light background |
| Silicon | `#C8CFD8` | Structural tint, separators, metallic depth |
| Light Steel Blue | `#A1B0CF` | Controlled accent, focus, directional highlight |
| Steel | `#5F6672` | Secondary text, supporting UI |
| Graphite | `#2B2C2F` | Primary text, dark logo, strong actions |

### Color rules
- Keep accents subtle and controlled.
- Highlights should feel thin, blade-like, and directional.
- Default to high-contrast light compositions.
- Use the liquid-metal texture only as an accent or hero treatment, not as a full-page fill.
- Do not drift into generic fintech blue, neon crypto gradients, or loud rainbow accents.

## Typography

Official typeface: **General Sans**.

Brand description from the guide: a rationalist sans serif that supports a clean, minimalistic approach.

### Web hierarchy

| Level | Weight | Size | Line height | Letter spacing |
| --- | --- | --- | --- | --- |
| Display | Medium | 82+ | 88 | -5% |
| Title XXL | Medium | 66 | 73 | -3% |
| Title XL | Medium | 48 | 56 | -3% |
| Title L | Medium | 40 | 48 | -3% |
| Title M | Medium | 32 | 40 | -3% |
| Title S | Medium | 26 | 34 | -3% |
| Headline | Medium | 21 | 28 | -3% |
| Headline Body | Medium | 16 | 24 | -3% |
| Body | Regular | 14 | 20 | 0% |
| Caption | Regular | 9 | 17 | 3% |

### Type rules
- Prefer medium weight for headlines and regular for body.
- Keep headlines large and short.
- Keep paragraphs short.
- Preserve strong contrast between heading and body text.
- Use Inter only as a last-resort fallback when General Sans cannot be loaded.

## Logo rules

- Use the real FAST logo. Never type the word FAST as a substitute.
- Clear space around the logo must equal the cap height of FAST.
- Place the logo only on legible dark or light backgrounds.
- Do not stretch, distort, or manipulate the logo.
- Do not pair the logo with icons that could read as part of the logo.
- Use these digital logo heights when possible: `16px`, `32px`, `64px`, `124px`.

## Partnership lockups

When FAST appears with a partner logo:
- use a vertical separator line
- keep equal distance between the separator and each logo relative to logo height
- respect FAST clear-space rules on both sides

## Layout and composition

For web usage:
- use generous whitespace
- use a minimalistic approach
- use large headlines
- use short paragraphs
- keep high contrast between heading and body

## Tie-break rule for this skill

When references disagree:
1. Official media kit wins for logo, palette, type, tone, spacing philosophy, and hero-art direction.
2. Shipped FAST surfaces win for interaction details, state design, and component behavior when the official guide is silent.
3. If a shipped component fights the official brand language, restyle it to the official guide instead of copying it literally.

import type { ReactNode } from 'react'

type FastWidgetShellProps = {
  eyebrow?: string
  title: string
  description?: string
  footer?: ReactNode
  children: ReactNode
}

export function FastWidgetShell({
  eyebrow,
  title,
  description,
  footer,
  children,
}: FastWidgetShellProps) {
  return (
    <main className="min-h-screen bg-fast-canvas px-4 py-10 sm:px-6">
      <div className="mx-auto flex min-h-[80vh] w-full max-w-widget items-center justify-center">
        <section className="w-full rounded-card border border-fast-border bg-fast-card p-5 shadow-[var(--shadow-card)] sm:p-7">
          <header className="mb-5 space-y-2">
            {eyebrow ? (
              <p className="text-[11px] font-medium uppercase tracking-[0.12em] text-fast-text-muted">
                {eyebrow}
              </p>
            ) : null}
            <div className="space-y-1.5">
              <h1 className="text-[21px] font-medium leading-7 tracking-[-0.03em] text-fast-text-primary">
                {title}
              </h1>
              {description ? (
                <p className="max-w-[42ch] text-sm leading-5 text-fast-text-muted">
                  {description}
                </p>
              ) : null}
            </div>
          </header>

          <div className="space-y-4">{children}</div>

          {footer ? <footer className="mt-5">{footer}</footer> : null}
        </section>
      </div>
    </main>
  )
}

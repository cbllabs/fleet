# FAST Demo Playbook

How to build demos that make people say "I want to invest."

## Three Demo Types

### 1. Landing Pages

**Structure (9-section standard):**
1. Navigation (brand + anchor links)
2. Hero (headline + subtitle + CTA + visual)
3. Social proof bar (logos, user count, press mentions)
4. Features / Benefits (3-6 feature cards)
5. How It Works (3-step process)
6. Testimonials (2-3 named reviews)
7. Pricing or secondary CTA
8. FAQ (4-6 questions)
9. Footer CTA + Footer

**Rules:**
- One goal per page. Every element serves that goal.
- Headline must pass the "so what?" test. Benefit-driven, not feature-driven.
- Primary CTA visible above the fold.
- Mobile-first: design for 375px width, then scale up.
- Performance: inline all CSS, lazy load images, total page under 1MB.

**Hero formula:**
```
[Specific benefit] + [for whom] + [key differentiator]
"Instant payments for AI agents — 100ms settlement, zero bridging"
```

### 2. Data Reports / Benchmark Slides

**The data storytelling formula:**
1. **The hook** — one line that makes them care
2. **The context** — what was measured and why (1-2 sentences max)
3. **The chart** — the visual proof
4. **The supporting stats** — 2-3 reinforcing numbers
5. **The implication** — so what? What does this mean?

**Rules:**
- One insight per slide. Don't cram.
- Chart readable from 10 feet away.
- FAST data in Graphite (`#2B2C2F`). Competitors in muted gray.
- Label everything. No ambiguity.
- Horizontal bars (easier than vertical).
- No pie charts. No 3D. No gradient fills.
- Fixed viewport (1920×1080) for presentations.

### 3. Interactive Widgets (like all-ramp)

**Structure:**
- Single card, centered, max-width 480px
- Form fields stack vertically with stagger animation
- State machine drives UI: IDLE → READY → PROCESSING → COMPLETE
- Status tracking replaces form within same card (no page navigation)

**Rules:**
- Must actually work. Broken demo is worse than no demo.
- Show real data (real balances, real transactions).
- Loading = shimmer skeletons, not spinners.
- Errors inline with retry action, never modals.
- Minimum clicks: connect → input → action → done.

## Making Numbers Land

- Bad: "15 LOC average"
- Good: "15 lines of code. 6x less than Circle."
- Best: Show the 15-line code block next to the 90-line competitor version.

## Surface recipes

See `references/surface-recipes.md` for detailed structure requirements per surface type.

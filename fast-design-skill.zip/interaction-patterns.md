# FAST Interaction Patterns

Advanced CSS and JS techniques for interactions that go beyond standard transitions.
Read when building tabs with active-state color shifts, hold-to-confirm flows,
scroll-triggered reveals, before/after comparison views, or any case where you need
programmatic animation without sacrificing GPU performance.

---

## clip-path: inset() — The Core Technique

`clip-path: inset(top right bottom left)` defines a rectangular clipping region.
Each value "eats into" the element from that side. This is one of the most powerful
animation tools in CSS — GPU-composited, interruptible, and fully animatable.

```css
/* Fully hidden (clipped from the right) */
.hidden   { clip-path: inset(0 100% 0 0); }

/* Fully visible */
.visible  { clip-path: inset(0 0 0 0); }

/* Reveal left-to-right */
.overlay {
  clip-path: inset(0 100% 0 0);
  transition: clip-path 200ms ease-out;
}
.trigger:active .overlay {
  clip-path: inset(0 0 0 0);
}
```

### Tab Active-State Color Transition

Tabs with different background and text color for the active state look wrong when
you try to animate the color properties directly — you see two states overlapping.
The correct technique: duplicate the tab list, style the copy as "active", clip it
so only the active tab is visible, animate the clip on tab change.

```html
<div class="tabs-wrapper">
  <!-- Base layer: inactive style -->
  <div class="tabs tabs-inactive" aria-hidden="true">
    <button>Deposits</button>
    <button>Withdrawals</button>
    <button>History</button>
  </div>

  <!-- Active layer: clipped to show only the selected tab -->
  <div class="tabs tabs-active" style="--active-left: 0px; --active-width: 96px;">
    <button>Deposits</button>
    <button>Withdrawals</button>
    <button>History</button>
  </div>
</div>
```

```css
.tabs-wrapper {
  position: relative;
}

.tabs {
  display: flex;
  gap: 4px;
}

.tabs-inactive button {
  background: var(--fast-canvas);
  color: var(--fast-text-muted);
}

.tabs-active {
  position: absolute;
  inset: 0;
  clip-path: inset(0 calc(100% - var(--active-left) - var(--active-width)) 0 var(--active-left) round 8px);
  transition: clip-path 200ms var(--ease-out, cubic-bezier(0.23, 1, 0.32, 1));
}

.tabs-active button {
  background: var(--fast-charcoal);
  color: #F6F8FA;
  pointer-events: none; /* clicks handled by inactive layer */
}
```

```js
function selectTab(index, buttonEl) {
  const left = buttonEl.offsetLeft;
  const width = buttonEl.offsetWidth;
  activeLayer.style.setProperty('--active-left', `${left}px`);
  activeLayer.style.setProperty('--active-width', `${width}px`);
}
```

This produces a seamless color transition that timing individual color properties can never match.

### Hold-to-Confirm (Destructive Actions)

Use on delete, disconnect, or any irreversible action. The slow fill signals deliberation;
the fast exit signals instant system response.

```html
<button class="hold-btn">
  <span class="hold-label">Hold to delete</span>
  <div class="hold-overlay">Delete</div>
</button>
```

```css
.hold-btn {
  position: relative;
  overflow: hidden;
  transition: transform 160ms ease-out;
}
.hold-btn:active {
  transform: scale(0.97);
}

.hold-overlay {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--fast-error, #E53E3E);
  color: white;

  /* Default: snap back fast */
  clip-path: inset(0 100% 0 0);
  transition: clip-path 200ms ease-out;
}

/* While held: slow fill */
.hold-btn:active .hold-overlay {
  clip-path: inset(0 0 0 0);
  transition: clip-path 2s linear;
}
```

Trigger the action in JS on `pointerup` only if the fill completed (track elapsed time):

```js
let pressStart;

btn.addEventListener('pointerdown', () => { pressStart = Date.now(); });
btn.addEventListener('pointerup', () => {
  if (Date.now() - pressStart >= 1900) confirmDelete();
});
```

### Scroll Reveal

See `animation-system.md` → Scroll Reveal for the standard `IntersectionObserver` pattern.
For entrance direction, start hidden from the bottom: `clip-path: inset(0 0 100% 0)`.

```css
.reveal {
  clip-path: inset(0 0 100% 0);
  transition: clip-path 600ms var(--ease-demo, cubic-bezier(0.16, 1, 0.3, 1));
}
.reveal.visible {
  clip-path: inset(0 0 0 0);
}
```

### Before/After Comparison Slider

```html
<div class="compare-wrapper">
  <img class="compare-before" src="before.png" alt="Before" />
  <div class="compare-after-clip">
    <img class="compare-after" src="after.png" alt="After" />
  </div>
  <div class="compare-handle" role="slider" aria-label="Comparison" />
</div>
```

```css
.compare-wrapper {
  position: relative;
  overflow: hidden;
  cursor: ew-resize;
}

.compare-after-clip {
  position: absolute;
  inset: 0;
  clip-path: inset(0 50% 0 0); /* start at 50% */
}

.compare-handle {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 50%;
  width: 2px;
  background: white;
  transform: translateX(-50%);
}
```

```js
wrapper.addEventListener('pointermove', e => {
  wrapper.setPointerCapture(e.pointerId);
  const rect = wrapper.getBoundingClientRect();
  const pct = ((e.clientX - rect.left) / rect.width) * 100;
  const right = Math.max(0, Math.min(100 - pct, 100));
  afterClip.style.clipPath = `inset(0 ${right}% 0 0)`;
  handle.style.left = `${pct}%`;
});
```

No extra DOM elements, no canvas, fully GPU-composited.

---

## WAAPI — Programmatic CSS Performance

The Web Animations API gives JS control with CSS-level performance (off main thread,
hardware-accelerated). Use when you need to trigger an animation from JS but don't
want the frame drops of Framer Motion under load.

```js
// Reveal element from bottom
element.animate(
  [
    { clipPath: 'inset(0 0 100% 0)', opacity: 0 },
    { clipPath: 'inset(0 0 0 0)',    opacity: 1 },
  ],
  {
    duration: 600,
    fill: 'forwards',
    easing: 'cubic-bezier(0.16, 1, 0.3, 1)',
  }
);

// Fade + scale entrance
element.animate(
  [
    { opacity: 0, transform: 'scale(0.95)' },
    { opacity: 1, transform: 'scale(1)' },
  ],
  {
    duration: 350,
    fill: 'forwards',
    easing: 'cubic-bezier(0.23, 1, 0.32, 1)',
  }
);
```

WAAPI animations are interruptible and can be paused, reversed, or cancelled:

```js
const anim = element.animate([...], { duration: 300 });
anim.cancel();   // snap to initial state
anim.reverse();  // play backwards from current position
```

Use WAAPI over Framer Motion when:
- The animation is triggered imperatively (not from React state)
- The page is loading simultaneously (Framer Motion will drop frames)
- You need precise JS-side timing control without a library

---

## Momentum-Based Dismissal

For swipeable components (drawers, cards), dismiss on velocity rather than distance.
A quick flick feels wrong if it requires dragging past an arbitrary threshold.

```js
let dragStartTime;
let dragStartY;

el.addEventListener('pointerdown', e => {
  dragStartTime = Date.now();
  dragStartY = e.clientY;
  el.setPointerCapture(e.pointerId);
});

el.addEventListener('pointerup', e => {
  const distance = e.clientY - dragStartY;
  const elapsed = Date.now() - dragStartTime;
  const velocity = Math.abs(distance) / elapsed;

  if (Math.abs(distance) >= DISMISS_THRESHOLD || velocity > 0.11) {
    dismiss();
  } else {
    snapBack();
  }
});
```

The `0.11` velocity threshold (px/ms) matches Vaul's drawer behavior. Adjust for the
component's weight — lighter elements should dismiss more easily.

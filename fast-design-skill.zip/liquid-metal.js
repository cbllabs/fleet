/* ============================================================================
 * FAST — Liquid Metal
 * ----------------------------------------------------------------------------
 * The canonical "liquid chrome" visual language. This module exposes three
 * tiers that share the same DNA (cool-grayscale palette, 261° flow direction,
 * subtle sheen band, soft vignette) so they compose cleanly across surfaces.
 *
 *   Tier 1  FastLiquidMetal.attach(el, preset)   — WebGL shader, the real thing.
 *   Tier 2  .fast-liquid-metal-css class         — CSS-only fallback / decorator.
 *   Tier 3  .fast-chrome-sheen class             — Flat chrome gradient for pills,
 *                                                  badges, buttons, chips.
 *
 * All three use the same 6-stop metallic palette captured from the production
 * `metallic-gradient` / `fast-badge` / `dropdown-gradient` utilities:
 *
 *   #F6F8FA  #C8CFD8  #E3E5EA  #F6F8FA  #DEE3E8  #5F6672
 *
 * PRESET PHILOSOPHY
 *   hero      — full-bleed, active flow, cinematic. Landing + section dividers.
 *   ambient   — slow drift, desaturated, sits behind content. Cards, empty states.
 *   spark     — small accent, high contrast. Badges, icons, loading states.
 *   still     — static poster (no rAF). For dense screens, tables, forms.
 *
 * ACCESSIBILITY
 *   All tiers respect `prefers-reduced-motion`. Tier 1 falls back to a
 *   still poster frame; Tier 2 freezes its gradient animation; Tier 3 is
 *   static to begin with.
 *
 * DEPENDENCIES
 *   Tier 1 needs Three.js r150+. Load via:
 *     <script src="https://unpkg.com/three@0.160.0/build/three.min.js"><\/script>
 *   Tiers 2 & 3 are dependency-free.
 * ========================================================================== */

(function (global) {
  'use strict';

  // The FAST chrome palette, normalized to [0..1] vec3 for the shader.
  const CHROME_PALETTE_HEX = [
    '#F6F8FA', // highlight
    '#C8CFD8', // cool mid
    '#E3E5EA', // warm mid
    '#F6F8FA', // peak
    '#DEE3E8', // soft
    '#5F6672', // shadow
  ];

  const hex2vec = (h) => {
    const s = h.replace('#', '');
    const r = parseInt(s.slice(0, 2), 16) / 255;
    const g = parseInt(s.slice(2, 4), 16) / 255;
    const b = parseInt(s.slice(4, 6), 16) / 255;
    return [r, g, b];
  };

  // ---------------------------------------------------------------------------
  // Shader — adapted from fast-website's ColorBends with a mercury-tuned path.
  // Key differences from the source:
  //   • Palette locked to chrome tones (we don't expose arbitrary colors).
  //   • Atmospheric base is cool gray, not teal.
  //   • Sheen band tuned to white (not cyan) for true chrome feel.
  //   • Presets control speed/warp/scale so designers don't touch uniforms.
  // ---------------------------------------------------------------------------
  const VERT = `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = vec4(position, 1.0);
    }
  `;

  const FRAG = `
    uniform vec2 uCanvas;
    uniform float uTime;
    uniform float uSpeed;
    uniform vec2 uRot;
    uniform float uScale;
    uniform float uFrequency;
    uniform float uWarpStrength;
    uniform vec2 uPointer;
    uniform float uMouseInfluence;
    uniform float uParallax;
    uniform float uNoise;
    uniform float uBrightness;
    uniform float uContrast;
    varying vec2 vUv;

    // Liquid-metal palette — deep graphite through polished silver.
    // Baked into the shader; no array uniform to go wrong across drivers.
    vec3 paletteColor(int i) {
      if (i == 0) return vec3(0.055, 0.063, 0.075); // #0E1013 — near-black
      if (i == 1) return vec3(0.200, 0.220, 0.255); // #333841 — graphite
      if (i == 2) return vec3(0.560, 0.600, 0.660); // #8F99A8 — pewter
      if (i == 3) return vec3(0.870, 0.900, 0.940); // #DEE6F0 — highlight
      if (i == 4) return vec3(0.110, 0.125, 0.150); // #1C2026 — deep shadow
      return vec3(0.700, 0.745, 0.800);             // #B3BECC — soft silver
    }

    void main() {
      float t = uTime * uSpeed;
      vec2 p = vUv * 2.0 - 1.0;
      p += uPointer * uParallax * 0.1;
      vec2 rp = vec2(p.x * uRot.x - p.y * uRot.y, p.x * uRot.y + p.y * uRot.x);
      vec2 q = vec2(rp.x * (uCanvas.x / uCanvas.y), rp.y);
      q /= max(uScale, 0.0001);
      q /= 0.5 + 0.2 * dot(q, q);
      q += 0.2 * cos(t) - 7.56;
      vec2 toward = (uPointer - rp);
      q += toward * uMouseInfluence * 0.2;

      vec3 col = vec3(0.0);
      vec2 s = q;
      for (int i = 0; i < 6; ++i) {
        s -= 0.01;
        vec2 r = sin(1.5 * (s.yx * uFrequency) + 2.0 * cos(s * uFrequency));
        float m0 = length(r + sin(5.0 * r.y * uFrequency - 3.0 * t + float(i)) / 4.0);
        float kBelow = clamp(uWarpStrength, 0.0, 1.0);
        float kMix = pow(kBelow, 0.3);
        float gain = 1.0 + max(uWarpStrength - 1.0, 0.0);
        vec2 disp = (r - s) * kBelow;
        vec2 warped = s + disp * gain;
        float m1 = length(warped + sin(5.0 * warped.y * uFrequency - 3.0 * t + float(i)) / 4.0);
        float m = mix(m0, m1, kMix);
        float w = 1.0 - exp(-6.0 / exp(6.0 * m));
        col += paletteColor(i) * w;
      }
      col = clamp(col, 0.0, 1.0);

      // Graphite atmospheric base — this IS the metal; the field flow modulates
      // it. Weighting the base heavier means "quiet" areas still read as
      // polished dark metal instead of crushing to black.
      float grad = clamp(0.5 + 0.5 * (rp.x * 0.4 - rp.y * 0.35), 0.0, 1.0);
      vec3 base = mix(vec3(0.18, 0.20, 0.24), vec3(0.42, 0.46, 0.52), grad);
      col = base + col * 0.55;

      // Specular catchlight — wide, bright reflection band. Liquid metal lives
      // or dies by this highlight.
      float bandCenter = rp.y + 0.25;
      float band = smoothstep(0.70, 0.0, abs(bandCenter));
      band = pow(band, 1.8);
      col += band * 0.35 * vec3(1.0);

      // Micro specular — a second thinner, hotter band for the "wet" look.
      float hot = smoothstep(0.22, 0.0, abs(rp.y + 0.08));
      hot = pow(hot, 3.0);
      col += hot * 0.22 * vec3(1.0);

      // Rim highlights along mercury creases — brightens where the field is
      // near mid-range, giving the sense of Fresnel-lit droplet edges.
      float bright = dot(col, vec3(0.33));
      float rim = smoothstep(0.20, 0.50, bright) * (1.0 - smoothstep(0.50, 0.90, bright));
      col = mix(col, vec3(0.96, 0.97, 1.00), rim * 0.30);

      // Gentle vignette — enough to settle the corners, not enough to crush.
      float vig = smoothstep(1.40, 0.20, length(p));
      col *= mix(0.72, 1.05, vig);

      // Brightness + contrast post
      col = (col - 0.5) * uContrast + 0.5 + (uBrightness - 1.0);
      col = clamp(col, 0.0, 1.0);

      if (uNoise > 0.0001) {
        float n = fract(sin(dot(gl_FragCoord.xy + vec2(uTime), vec2(12.9898, 78.233))) * 43758.5453123);
        col += (n - 0.5) * uNoise;
        col = clamp(col, 0.0, 1.0);
      }

      gl_FragColor = vec4(col, 1.0);
    }
  `;

  // ---------------------------------------------------------------------------
  // Presets — the four named intensities. Each one is tuned so that a designer
  // can say "use the `ambient` preset" and get the right feel without fiddling.
  // ---------------------------------------------------------------------------
  const PRESETS = {
    // Cinematic hero — what you see at fast.xyz. Active flow.
    hero: {
      speed: 0.28,
      scale: 1.35,
      frequency: 1.15,
      warpStrength: 1.2,
      mouseInfluence: 0.6,
      parallax: 0.4,
      noise: 0.04,
      rotation: 261,
      brightness: 1.0,
      contrast: 1.12,
    },
    // Sits behind content. Subtle. Card backgrounds, dividers.
    ambient: {
      speed: 0.08,
      scale: 2.1,
      frequency: 0.85,
      warpStrength: 0.75,
      mouseInfluence: 0.2,
      parallax: 0.2,
      noise: 0.02,
      rotation: 261,
      brightness: 1.02,
      contrast: 1.05,
    },
    // Small punchy accent. Loading states, empty states, icon fills.
    spark: {
      speed: 0.45,
      scale: 0.9,
      frequency: 1.4,
      warpStrength: 1.5,
      mouseInfluence: 0.0,
      parallax: 0.0,
      noise: 0.03,
      rotation: 261,
      brightness: 1.0,
      contrast: 1.18,
    },
    // Static poster frame. No rAF.
    still: {
      speed: 0,
      scale: 1.35,
      frequency: 1.1,
      warpStrength: 1.0,
      mouseInfluence: 0,
      parallax: 0,
      noise: 0.03,
      rotation: 261,
      brightness: 0.96,
      contrast: 1.20,
      staticTime: 12.4, // fixed time offset — picks a nice-looking frame
    },
  };

  // ---------------------------------------------------------------------------
  // Tier 1 — WebGL attach
  // ---------------------------------------------------------------------------
  function attach(element, options) {
    if (!element) throw new Error('[liquid-metal] attach() needs an element');
    if (typeof THREE === 'undefined') {
      console.warn('[liquid-metal] Three.js not found. Falling back to CSS tier.');
      element.classList.add('fast-liquid-metal-css');
      return { destroy() { element.classList.remove('fast-liquid-metal-css'); } };
    }

    const opts = Object.assign({}, PRESETS.hero, options || {});
    const presetName = (options && options.preset) || 'hero';
    if (PRESETS[presetName]) Object.assign(opts, PRESETS[presetName], options || {});

    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const isStatic = opts.speed === 0 || reducedMotion;

    const scene = new THREE.Scene();
    const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    const geo = new THREE.PlaneGeometry(2, 2);

    const colorsUniform = null; // palette is baked into the shader

    const material = new THREE.ShaderMaterial({
      vertexShader: VERT,
      fragmentShader: FRAG,
      transparent: false,
      depthTest: false,
      depthWrite: false,
      uniforms: {
        uCanvas: { value: new THREE.Vector2(1, 1) },
        uTime: { value: opts.staticTime || 0 },
        uSpeed: { value: opts.speed },
        uRot: { value: new THREE.Vector2(1, 0) },
        uScale: { value: opts.scale },
        uFrequency: { value: opts.frequency },
        uWarpStrength: { value: opts.warpStrength },
        uPointer: { value: new THREE.Vector2(0, 0) },
        uMouseInfluence: { value: opts.mouseInfluence },
        uParallax: { value: opts.parallax },
        uNoise: { value: opts.noise },
        uBrightness: { value: opts.brightness },
        uContrast: { value: opts.contrast },
      },
    });

    const mesh = new THREE.Mesh(geo, material);
    scene.add(mesh);
    scene.updateMatrixWorld(true);
    camera.updateProjectionMatrix();
    camera.updateMatrixWorld(true);

    const renderer = new THREE.WebGLRenderer({ antialias: false, alpha: false, premultipliedAlpha: false, powerPreference: 'high-performance', preserveDrawingBuffer: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setClearColor(0x000000, 1);
    const canvas = renderer.domElement;
    canvas.style.cssText = 'width:100%;height:100%;display:block;';
    element.appendChild(canvas);

    // Rotation matrix
    const rad = (opts.rotation * Math.PI) / 180;
    material.uniforms.uRot.value.set(Math.cos(rad), Math.sin(rad));

    let rafId = null;
    const pointerTarget = new THREE.Vector2(0, 0);
    const pointerCurrent = new THREE.Vector2(0, 0);

    function resize() {
      const w = element.clientWidth || 1;
      const h = element.clientHeight || 1;
      renderer.setSize(w, h, false);
      material.uniforms.uCanvas.value.set(w, h);
    }
    resize();

    const ro = ('ResizeObserver' in window) ? new ResizeObserver(resize) : null;
    if (ro) ro.observe(element); else window.addEventListener('resize', resize);

    function onPointer(e) {
      const rect = element.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / (rect.width || 1)) * 2 - 1;
      const y = -(((e.clientY - rect.top) / (rect.height || 1)) * 2 - 1);
      pointerTarget.set(x, y);
    }
    if (opts.mouseInfluence > 0 || opts.parallax > 0) {
      element.addEventListener('pointermove', onPointer);
    }

    const clock = new THREE.Clock();

    // Always render at least one frame synchronously at a non-zero time so the
    // canvas is never blank — even in screenshot tools, print contexts, or tabs
    // where RAF is suspended. The animated path will overwrite this frame as
    // soon as the first RAF fires.
    material.uniforms.uTime.value = opts.staticTime != null ? opts.staticTime : 2.4;
    // Three.js compiles shader programs lazily on first render, so the first
    // render() call after attach may produce no output. Compile synchronously
    // first, then render.
    if (typeof renderer.compile === 'function') renderer.compile(scene, camera);
    renderer.render(scene, camera);
    // Double-tap render to defeat any remaining lazy compilation on WebGL2.
    renderer.render(scene, camera);

    if (!isStatic) {
      clock.start();
      const loop = () => {
        const dt = clock.getDelta();
        material.uniforms.uTime.value = clock.elapsedTime + 2.4;
        pointerCurrent.lerp(pointerTarget, Math.min(1, dt * 8));
        material.uniforms.uPointer.value.copy(pointerCurrent);
        renderer.render(scene, camera);
        rafId = requestAnimationFrame(loop);
      };
      rafId = requestAnimationFrame(loop);
    }

    return {
      element,
      renderer,
      material,
      setPreset(name) {
        if (!PRESETS[name]) return;
        const p = PRESETS[name];
        material.uniforms.uSpeed.value = p.speed;
        material.uniforms.uScale.value = p.scale;
        material.uniforms.uFrequency.value = p.frequency;
        material.uniforms.uWarpStrength.value = p.warpStrength;
        material.uniforms.uMouseInfluence.value = p.mouseInfluence;
        material.uniforms.uParallax.value = p.parallax;
        material.uniforms.uNoise.value = p.noise;
        material.uniforms.uBrightness.value = p.brightness;
        material.uniforms.uContrast.value = p.contrast;
        const r = (p.rotation * Math.PI) / 180;
        material.uniforms.uRot.value.set(Math.cos(r), Math.sin(r));
      },
      destroy() {
        if (rafId) cancelAnimationFrame(rafId);
        if (ro) ro.disconnect(); else window.removeEventListener('resize', resize);
        element.removeEventListener('pointermove', onPointer);
        geo.dispose();
        material.dispose();
        renderer.dispose();
        if (canvas.parentElement === element) element.removeChild(canvas);
      },
    };
  }

  // ---------------------------------------------------------------------------
  // Public API
  // ---------------------------------------------------------------------------
  const FastLiquidMetal = {
    attach,
    PRESETS,
    PALETTE: CHROME_PALETTE_HEX.slice(),
    // Auto-attach helper for declarative usage: any element with
    // `data-fast-liquid-metal="hero"` gets wired up on DOMContentLoaded.
    autoAttach() {
      document.querySelectorAll('[data-fast-liquid-metal]').forEach((el) => {
        if (el.__flm) return;
        const preset = el.getAttribute('data-fast-liquid-metal') || 'hero';
        try { el.__flm = attach(el, { preset }); } catch (e) { console.warn(e); }
      });
    },
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', FastLiquidMetal.autoAttach);
  } else {
    FastLiquidMetal.autoAttach();
  }

  global.FastLiquidMetal = FastLiquidMetal;
})(typeof window !== 'undefined' ? window : this);

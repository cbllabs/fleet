# FAST UX Principles

Use these principles to make a FAST interface feel like FAST.

## 1. Feel like solid infrastructure in fluid motion

FAST should feel precise, calm, and engineered.

- Aim for speed without aggression.
- Aim for flow without chaos.
- Make motion feel directional, not theatrical.
- Make the product feel expensive because it is controlled, not because it is loud.

## 2. Default to the light brand expression

The primary FAST look is light, minimal, and high contrast.

- Use Platinum as the main canvas.
- Use dark sections only as accents, proof callouts, or hero contrast.
- Do not make dark mode the main brand expression unless asked.
- Keep the overall feel cool and metallic, not warm or creamy.

## 3. Let whitespace do the work

The media kit is explicit here.

- Use generous whitespace.
- Give the main action room to breathe.
- Avoid stuffing secondary details too close to the hero message.
- If the screen feels crowded, remove or compress something.

## 4. Make one thing obvious

Every screen needs one dominant idea.

- One primary action per view.
- One primary proof block per page.
- One dominant panel per dashboard screen.

If everything is shouting, nothing lands.

## 5. Use proof over decoration

FAST looks strongest when the interface shows evidence.

Prefer:
- metrics
- code snippets
- workflow clarity
- balances, statuses, confirmations
- before/after comparisons
- simple benchmark visuals

Avoid decorative filler that does not deepen trust.

## 6. Keep hierarchy sharp

Use the official type system, not arbitrary font jumps.

- Large headlines.
- Short paragraphs.
- Strong contrast between heading and body.
- Medium-weight headlines, regular-weight body.
- Secondary text should step back clearly.

A FAST interface should read cleanly in a quick glance.

## 7. Use accents like a blade, not a paint bucket

The palette is controlled.

- Use Light Steel Blue for directional emphasis, focus, and selection.
- Use Silicon for quiet structure and metallic depth.
- Keep accents thin, blade-like, and intentional.
- Do not flood the page with brand color.

## 8. Use liquid metal carefully

Liquid metal is the emotional accent, not the whole system.

- Use it in hero areas, splash moments, or key proof scenes.
- Keep the rest of the UI mostly typography, whitespace, surfaces, and data.
- If every section uses the motif, the brand gets cheap fast.

## 9. Make states feel designed

The polish is usually in the state design.

- Loading should feel intentional.
- Empty should still feel useful.
- Error should explain and recover.
- Success should feel calm and certain.

Do not bolt these on at the end with generic placeholders.

## 10. Write like an adult

FAST copy should feel precise and technically confident.

- Use short, declarative lines.
- Prefer specifics over hype.
- Use real numbers when possible.
- Cut filler adjectives.
- Sound calm, not chest-thumpy.

## 11. Build for screenshots

Most FAST demos get shared as screenshots, short videos, or live walkthroughs.

- Make the first screen strong enough to stand alone.
- Ensure the hero or primary state reads clearly in a crop.
- Check spacing, alignment, and status clarity at thumbnail scale.

## 12. Use elevation sparingly

Cards exist only when the elevation communicates hierarchy — when something is literally above something else. When in doubt, remove the box.

- Use `border-t` or `divide-y` to group related items without boxing them.
- Use generous spacing and negative space to create structure without containers.
- Use cards for widgets, stats blocks, and isolated actions that need a clear boundary.
- Do not put a card around everything. Flat, well-spaced content beats over-boxed content.

High-density FAST layouts should replace cards with lines and space, not stack more cards inside cards.

---

## FAST smell test — explicit tells

If you see any of these in the output, fix them before shipping.

### Visual tells
- Pure black (`#000000`) anywhere — use Charcoal or off-black
- Purple/violet gradients or neon glow effects — the "AI purple" fingerprint
- Oversaturated accent colors — FAST accents are cool and metallic, not vivid
- Three equal-height feature cards in a horizontal row — the most common AI layout cliché
- Centered hero section with centered headline and centered CTA — use left-aligned or split-screen instead
- Random dark section breaking an otherwise light page — commit to the light theme or mark the dark section intentionally
- Shadows that are pure black at low opacity — tint shadows to match the background hue (cool blue-gray on Platinum, not `rgba(0,0,0,0.1)`)
- Flat sections with no visual depth — hero and feature sections need a liquid metal accent, a subtle radial gradient, or a low-opacity background image to avoid feeling unfinished

### Content tells
- Fake round numbers (`99.99%`, `50%`, `$100`) — use organic data (`47.2%`, `$99.00`, `+1 (312) 847-1928`)
- Generic placeholder names ("John Doe", "Acme Corp", "Jane Smith")
- AI copywriting clichés in headlines or CTAs — see `copy-guidelines.md` for the banned list
- Title Case On Every Header — use sentence case
- "!" in success messages — be confident, not exclamatory
- "Oops!" as an error prefix — be direct: "Connection failed. Try again."

### Technical tells
- `h-screen` on any hero or full-height section — iOS Safari jumps the viewport when the address bar shows/hides; use `min-h-[100dvh]`
- Flexbox percentage math (`calc(33% - 1rem)`) instead of CSS Grid
- Hover animations without `@media (hover: hover) and (pointer: fine)` — touch devices trigger hover on tap
- Generic circular spinner for loading states — use skeletal shimmer matching the layout shape
- `backdrop-blur` on scrolling containers — GPU repaint on every scroll frame; apply only to `position: fixed` or `sticky` elements

If it feels like technical minimalism, quiet confidence, generous whitespace, and sharp proof, you are close.

# FAST Brand Assets

Use real FAST assets. Do not fake brand elements with typed text or generic icons.

---

## Logo

The "A" in FAST has **no crossbar** (inverted V shape). Always use the SVG file.

**Bundled in this skill:**
- `assets/fast-logo-dark.svg` — for light backgrounds (Platinum canvas)
- `assets/fast-logo-light.svg` — for dark backgrounds

**Workspace locations:**
- `all-ramp/public/fast-logo.svg`
- `pi2labs-website/public/fast-logo.svg`
- Media Kit SVGs: `Fast-Media-Kit.zip/Logos/SVG/FAST-Logo-Dark.svg`

**Scale guidelines (from Media Kit):** 16px, 32px, 64px, 124px

**Rules:**
- Clear space = cap height of FAST on all sides
- Only on dark or light legible backgrounds — never on busy patterns
- Never stretch, distort, or add effects
- Never pair with icons that could read as part of the logo

---

## Fonts — General Sans

### Source locations in workspace

**OTF (Next.js `next/font/local`):**
- `all-ramp/public/fonts/GeneralSans-Light.otf` (300)
- `all-ramp/public/fonts/GeneralSans-Regular.otf` (400)
- `all-ramp/public/fonts/GeneralSans-Medium.otf` (500)
- `all-ramp/public/fonts/GeneralSans-Semibold.otf` (600)

**WOFF2 (preferred for plain web — smaller):**
- `fastset-wallet-browser-extension/src/assets/font/general-sans/GeneralSans-Variable.woff2` (all weights)
- `fastset-wallet-browser-extension/src/assets/font/general-sans/GeneralSans-Regular.woff2` (400)
- `fastset-wallet-browser-extension/src/assets/font/general-sans/GeneralSans-Medium.woff2` (500)
- `fastset-wallet-browser-extension/src/assets/font/general-sans/GeneralSans-Semibold.woff2` (600)

**From Media Kit (all weights + web formats):**
- `Fast-Media-Kit.zip/General Sans/Fonts/OTF/` — all OTF weights
- `Fast-Media-Kit.zip/General Sans/Fonts/WEB/fonts/` — WOFF2, WOFF, TTF for all weights

### Setup for new FAST projects

```bash
mkdir -p public/fonts
cp ~/openclaw-workspace/all-ramp/public/fast-logo.svg public/
cp ~/openclaw-workspace/all-ramp/public/fonts/GeneralSans-*.otf public/fonts/
```

### Usage with Next.js (local font)

```ts
import localFont from 'next/font/local';

const generalSans = localFont({
  src: [
    { path: '../public/fonts/GeneralSans-Light.otf',    weight: '300' },
    { path: '../public/fonts/GeneralSans-Regular.otf',  weight: '400' },
    { path: '../public/fonts/GeneralSans-Medium.otf',   weight: '500' },
    { path: '../public/fonts/GeneralSans-Semibold.otf', weight: '600' },
  ],
  variable: '--font-general-sans',
  display: 'swap',
});
```

### Usage with plain CSS (@font-face)

```css
/* Option A: Variable font (one file, all weights) */
@font-face {
  font-family: 'General Sans';
  src: url('/fonts/GeneralSans-Variable.woff2') format('woff2');
  font-weight: 300 600;
  font-display: swap;
}

/* Option B: Individual weights (better control) */
@font-face {
  font-family: 'General Sans';
  src: url('/fonts/GeneralSans-Regular.woff2') format('woff2');
  font-weight: 400; font-style: normal; font-display: swap;
}
@font-face {
  font-family: 'General Sans';
  src: url('/fonts/GeneralSans-Medium.woff2') format('woff2');
  font-weight: 500; font-style: normal; font-display: swap;
}
@font-face {
  font-family: 'General Sans';
  src: url('/fonts/GeneralSans-Semibold.woff2') format('woff2');
  font-weight: 600; font-style: normal; font-display: swap;
}
```

### Font stack

```css
font-family: 'General Sans', 'Inter', system-ui, -apple-system, sans-serif;
```

### Production weights (load only what you use)

| Weight | Class name | Used for |
|---|---|---|
| 400 Regular | — | body text, labels |
| 500 Medium | `font-medium` | inputs, buttons, pills, headlines |
| 600 Semibold | `font-semibold` | widget titles, strong headings |

Never load more than 3 weights per page.

---

## Fallback font

Inter (Google Fonts) is the approved fallback when General Sans cannot load. System-ui is acceptable for rapid prototyping only.

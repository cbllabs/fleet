# FAST Landing Page Outline

Use this as a copy and structure starter, then adapt it to the actual product.

## 1. Nav
- FAST wordmark
- 2 to 4 anchor links max
- one compact CTA

## 2. Hero
- headline with one concrete promise
- short supporting line
- one primary CTA
- one proof visual, product frame, or benchmark snapshot

## 3. Credibility strip
- partner logos, benchmark callout, traction line, or one strong credibility sentence

## 4. Benefit blocks
- 3 cards max to start
- each card: one headline, one sentence, one proof point if possible

## 5. How it works
- 3 steps
- keep each step short

## 6. Proof section
- chart, code example, workflow preview, or product screenshot
- this is where FAST should feel undeniable

## 7. FAQ or objection handling
- answer the real hesitation, not filler questions

## 8. Footer CTA
- restate the value clearly
- one final action

## Copy reminders
- keep headlines short
- use specific numbers where possible
- avoid hype words when proof will do the job better

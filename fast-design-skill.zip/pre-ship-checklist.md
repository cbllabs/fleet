# FAST Pre-Ship Checklist

Use this before calling any FAST UI done.

## Brand correctness

- [ ] FAST light theme is the default unless the user explicitly asked for dark.
- [ ] Canonical FAST tokens are applied.
- [ ] The FAST logo uses the real asset, not typed text.
- [ ] General Sans is loaded when available, or Inter is used as the fallback.
- [ ] The UI still feels mostly grayscale, with color used for meaning.

## Surface completeness

- [ ] The work clearly matches one surface recipe.
- [ ] The primary action or primary insight is obvious in the first viewport.
- [ ] The first screen is screenshot-worthy.
- [ ] There are no placeholder logos, fake numbers, lorem ipsum, or dead buttons.

## States

LLMs naturally generate the successful, static state. The other states are where polish lives.

- [ ] Loading state uses skeletal shimmer matching the layout shape — not a generic circular spinner.
- [ ] Empty state is a composed view that indicates how to populate data, not just blank space.
- [ ] Error state is inline, names the problem, and gives a recovery action ("Try again", "Check connection").
- [ ] Success or completion state exists and feels calm — no exclamation marks.
- [ ] Disabled states are visually clear.

## Responsive and accessibility

- [ ] Mobile works at 375px width.
- [ ] Full-height hero sections use `min-h-[100dvh]`, not `h-screen` — iOS Safari jumps the viewport when the address bar shows/hides.
- [ ] Multi-column layouts use CSS Grid, not flexbox `calc()` percentage math.
- [ ] Desktop still feels calm, not stretched and empty.
- [ ] There is no horizontal scroll.
- [ ] Headlines use `text-wrap: balance` to prevent single-word orphans on the last line.
- [ ] Focus states are visible.
- [ ] Touch targets are at least 44px where relevant.
- [ ] Color contrast is acceptable.
- [ ] Motion respects `prefers-reduced-motion`.

## Metadata and launch assets

### For Next.js App Router projects
- [ ] `app/icon.png` or equivalent exists.
- [ ] `app/opengraph-image.png` or `.jpg` exists, or an equivalent OG asset is wired.
- [ ] `app/twitter-image.png` or `.jpg` exists when a separate Twitter preview is needed.
- [ ] Metadata title and description are set.

### For generic web projects
- [ ] `favicon.ico` or `favicon.png` exists.
- [ ] OG image exists in a stable public path.
- [ ] Twitter preview image exists if separate from OG.
- [ ] HTML metadata or framework metadata includes title, description, OG tags, and Twitter tags.

### For extension or app surfaces
- [ ] Required app icons or extension icons exist.
- [ ] Store or launcher-facing images are not forgotten.
- [ ] The surface has a sensible display name and description.

## Content QA

- [ ] Headline says something specific.
- [ ] Headlines use sentence case, not Title Case On Every Word.
- [ ] CTA text is action-oriented.
- [ ] Labels and microcopy are concise.
- [ ] User-facing text avoids avoidable crypto jargon unless the audience expects it.
- [ ] Numbers are labeled clearly, make a real point, and use organic values (not round placeholders like 99.99% or $100).
- [ ] No AI copywriting clichés — see `copy-guidelines.md` for the banned list.

## Animation quality

- [ ] No `ease-in` on any UI animation — use `ease-out` or a custom curve from the FAST easing preset.
- [ ] Nothing enters from `scale(0)` — minimum starting state is `scale(0.95)` with `opacity: 0`.
- [ ] Keyboard-triggered actions have no animation (command palette, shortcuts).
- [ ] Popovers and dropdowns scale from their trigger, not from center. Modals are the exception.
- [ ] All UI animations complete within 300ms (deliberate hold-to-confirm patterns are exempt).
- [ ] Elements that animate frequently (toasts, list items) use CSS transitions, not keyframes.
- [ ] `prefers-reduced-motion` is handled — either via the global reset or explicitly per component.
- [ ] Hover animations are wrapped in `@media (hover: hover) and (pointer: fine)`.
- [ ] Framer Motion shorthand (`x`, `y`, `scale` props) replaced with `transform` string in perf-critical paths.

## Performance and trust

- [ ] `backdrop-blur` is applied only to `position: fixed` or `sticky` elements — never to scrolling containers (continuous GPU repaint).
- [ ] Grain or noise texture overlays use a `position: fixed; pointer-events: none` pseudo-element, not a scrolling layer.
- [ ] `useEffect` animation blocks include cleanup functions (`return () => ...`) to prevent memory leaks.
- [ ] Large images are compressed appropriately.
- [ ] Broken links are fixed.
- [ ] The hero, widget, or main view loads without obvious jank.
- [ ] Analytics or tracking is included only if the task actually needs it.

## Strategic omissions (what AI typically forgets)

- [ ] Every page has a way back — no dead ends in user flows.
- [ ] Forms have client-side validation for required fields and format checks.
- [ ] A custom 404 page exists for sites and apps (or is planned).
- [ ] Footer includes privacy policy and terms links if required.
- [ ] Keyboard users can reach all interactive elements — there are no focus traps.

## Final QA

- [ ] Share preview was sanity-checked if metadata changed.
- [ ] Screenshots or a running preview were reviewed.
- [ ] `visual-qa` was used when a screenshot or live preview was available.
- [ ] Any missing custom visual work was routed to `creative-direction` instead of hand-waving it.

If any checked box would honestly be "not yet", do not claim the work is finished.

# FAST Design Tokens

Source of truth hierarchy:
1. **FAST Media Kit** (`Fast-BrandGuidelines.pdf`) — canonical for the 5 brand colors, typography, and logo.
2. **All-ramp production** — canonical for UI-specific tokens (shadows, spacing, components) where the Media Kit is silent.

---

## Color Tokens

### Brand Palette (Media Kit — non-negotiable)

| Name | Hex | Role |
|---|---|---|
| Platinum | `#F6F8FA` | Page background, canvas |
| Silicon | `#C8CFD8` | Structural tint, separators, metallic depth |
| Light Steel Blue | `#A1B0CF` | Accent, focus, directional highlight |
| Steel | `#5F6672` | Secondary text, supporting UI |
| Graphite | `#2B2C2F` | Primary text, dark logo, strong actions |

### UI Token Mapping (implementation-ready)

| Token | Value | Tailwind Class | Usage |
|---|---|---|---|
| Canvas | `#F6F8FA` | `bg-fast-canvas` | Page background (= Platinum) |
| Card | `#FFFFFF` | `bg-fast-card` | Card/widget surfaces |
| Surface | `rgba(200,207,216,0.18)` | `bg-fast-surface` | Recessed areas, info bars |
| Charcoal | `#2B2C2F` | `text-fast-charcoal` | Primary text, buttons (= Graphite) |
| Text Primary | `#2B2C2F` | `text-fast-text-primary` | Headings, important text |
| Text Muted | `#5F6672` | `text-fast-text-muted` | Labels, secondary text (= Steel) |
| Success | `#27C93F` | `text-fast-success` | Completion, positive status |
| Error | `#E07070` | `text-fast-error` | Error states |
| Brand | `#A1B0CF` | `text-fast-brand` | Focus rings, accents (= Light Steel Blue) |
| Border | `rgba(0,0,0,0.06)` | `border-fast-border` | Subtle dividers |
| Border Focus | `#A1B0CF` | `border-fast-border-focus` | Input focus state |
| Pill BG | `rgba(161,176,207,0.10)` | `bg-fast-pill-bg` | Badge/pill backgrounds |
| Ring | `#A1B0CF` | `ring-fast-ring` | Focus ring |

**Note:** Success (`#27C93F`) and Error (`#E07070`) are UI-only extensions — the Media Kit is silent on these. Values are from all-ramp production.

### Data Visualization (pitch deck + comparison tables only)

| Token | Value | Usage |
|---|---|---|
| Lavender | `#C5CEE8` | FAST row highlight in comparison tables |
| Data Green | `#02cb97` | Positive data (pass, growth) |
| Data Orange | `#ffa159` | Caution data (limits, warnings) |
| Data Red | `#EA4335` | Negative data (fail, errors) |
| Text Tertiary | `#80868B` | Axis labels, captions |
| Text on Dark | `#F7F8FA` | White text on dark sections |
| BG Dark | `#0a0a0f` | Dark sections, footer |

---

## Shadow Tokens

```css
--shadow-card:         0 8px 24px -8px rgba(0,0,0,0.1);
--shadow-input-inner:  inset 0 1px 2px rgba(0,0,0,0.04);
--shadow-button:       0 1px 1px 0 rgba(0,0,0,0.10);
--shadow-button-hover: 0 2px 4px 0 rgba(0,0,0,0.15);
```

---

## Spacing Tokens

| Token | Value | Usage |
|---|---|---|
| Widget max-width | `480px` | Max card/widget width |
| Card radius | `14px` | Primary card border-radius |
| Inner radius | `12px` (rounded-xl) | Inputs, inner cards |
| Segment radius | `10px` (rounded-[10px]) | Segmented control options |
| Pill radius | `9999px` (rounded-full) | Buttons, badges, pills |
| Card padding | `20px / 28px` | `p-5 sm:p-7` mobile/desktop |
| Input padding | `12px 16px` | `px-4 py-3` |
| Section gap | `16px` | `space-y-4` between form sections |
| Pill padding | `4px 10px` | `px-2.5 py-1` |
| Nav height | `56px` | `h-14` |

---

## Typography Tokens

### Official Web Scale (from Media Kit)

| Level | Weight | Size | Line height | Letter spacing |
|---|---|---|---|---|
| Display | Medium | 82+ | 88 | -5% |
| Title XXL | Medium | 66 | 73 | -3% |
| Title XL | Medium | 48 | 56 | -3% |
| Title L | Medium | 40 | 48 | -3% |
| Title M | Medium | 32 | 40 | -3% |
| Title S | Medium | 26 | 34 | -3% |
| Headline | Medium | 21 | 28 | -3% |
| Headline Body | Medium | 16 | 24 | -3% |
| Body | Regular | 14 | 20 | 0% |
| Caption | Regular | 9 | 17 | 3% |

### UI / Widget Scale (all-ramp production)

| Element | Size | Weight | Notes |
|---|---|---|---|
| Widget title | 18px | 600 | `tracking-tight` |
| Amount input | 24px | 500 | hero interaction |
| Body/button | 16px | 500 | `tracking-[-0.48px]` |
| Input value | 14px | 500 | normal |
| Label | 12px | 400 | text-muted |
| Summary text | 12px | 400 | text-muted, inside surface bg |
| Quick pills | 12px | 500 | pill buttons |
| Micro text | 10px | 400 | text-muted, `leading-tight` |

### Font Stack

```css
--font-sans: var(--font-general-sans), "Inter", system-ui, -apple-system, sans-serif;
--font-mono: ui-monospace, SFMono-Regular, Menlo, monospace;
```

---

## Tailwind v4 @theme Block (copy-paste ready)

```css
@theme inline {
  --font-sans: var(--font-general-sans), "Inter", system-ui, -apple-system, sans-serif;
  --font-mono: ui-monospace, SFMono-Regular, Menlo, monospace;

  /* Brand palette (Media Kit canonical) */
  --color-fast-canvas:        #F6F8FA;
  --color-fast-card:          #FFFFFF;
  --color-fast-surface:       rgba(200,207,216,0.18);
  --color-fast-charcoal:      #2B2C2F;
  --color-fast-text-primary:  #2B2C2F;
  --color-fast-text-muted:    #5F6672;
  --color-fast-success:       #27C93F;
  --color-fast-error:         #E07070;
  --color-fast-brand:         #A1B0CF;
  --color-fast-border:        rgba(0,0,0,0.06);
  --color-fast-border-focus:  #A1B0CF;
  --color-fast-pill-bg:       rgba(161,176,207,0.10);
  --color-fast-ring:          #A1B0CF;

  /* Shadows */
  --shadow-card:        0 8px 24px -8px rgba(0,0,0,0.1);
  --shadow-input-inner: inset 0 1px 2px rgba(0,0,0,0.04);

  /* Layout */
  --max-width-widget: 480px;
  --radius-card:      14px;
}
```

---

## CSS Custom Properties Block (for plain HTML/CSS projects)

```css
:root {
  /* Brand palette */
  --fast-platinum:     #F6F8FA;
  --fast-silicon:      #C8CFD8;
  --fast-light-steel:  #A1B0CF;
  --fast-steel:        #5F6672;
  --fast-graphite:     #2B2C2F;

  /* UI tokens */
  --fast-canvas:       #F6F8FA;
  --fast-card:         #FFFFFF;
  --fast-surface:      rgba(200,207,216,0.18);
  --fast-charcoal:     #2B2C2F;
  --fast-text-primary: #2B2C2F;
  --fast-text-muted:   #5F6672;
  --fast-success:      #27C93F;
  --fast-error:        #E07070;
  --fast-brand:        #A1B0CF;
  --fast-border:       rgba(0,0,0,0.06);
  --fast-border-focus: #A1B0CF;
  --fast-pill-bg:      rgba(161,176,207,0.10);
  --fast-ring:         #A1B0CF;

  --shadow-card:        0 8px 24px -8px rgba(0,0,0,0.1);
  --shadow-input-inner: inset 0 1px 2px rgba(0,0,0,0.04);
  --max-width-widget:   480px;
  --radius-card:        14px;
  --radius-inner:       12px;

  --font-sans: 'General Sans', 'Inter', system-ui, -apple-system, sans-serif;
  --font-mono: ui-monospace, SFMono-Regular, Menlo, monospace;
}
```

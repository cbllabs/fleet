# FAST Surface Recipes

Use one recipe per primary surface. Do not blend patterns unless the user explicitly asks.

## Table of contents
- Landing page
- Interactive widget
- App shell / dashboard
- Browser extension / compact utility
- Benchmark page / report / demo page

## Landing page

### Job
Convert a visitor around one product, launch, or narrative.

### Structure
1. Nav
2. Hero with one primary CTA
3. Proof strip or credibility bar
4. 3 to 6 feature or benefit blocks
5. How it works
6. Product visual, benchmark, or workflow proof
7. Secondary CTA or FAQ
8. Footer

### Rules
- Put the real point above the fold.
- Use one primary CTA, not two equal CTAs.
- Make the hero visual or proof block screenshot-worthy.
- Keep sections spacious and quiet. Let the proof breathe.
- If the page is technical, show code, metrics, or flow proof early.

### Must include
- Mobile-safe hero
- Real CTA copy
- Social proof or proof of capability
- Clear footer CTA
- OG and share metadata

### Avoid
- Three-column text walls
- Generic gradients or fintech-blue hero sections
- Empty testimonials or fake logos

## Interactive widget

### Job
Help the user complete one contained action in the fewest clear steps.

### Structure
- Single centered card or tight container
- One main input cluster
- One primary action
- In-place success state or status view

### Rules
- Keep max width tight, around the FAST single-card widget scale.
- Put state changes inside the same container.
- Use inline validation and inline retry.
- Use shimmer for loading content, not full-screen spinners.
- Make disabled and loading states obvious.

### Must include
- Happy path
- Loading state
- Empty state, if data-driven
- Inline error state with retry
- Success or completion state

### Avoid
- Navigation-heavy flows
- Multi-screen wizard behavior unless absolutely necessary
- Modal errors

## App shell / dashboard

### Job
Give the user orientation, confidence, and fast access to the main workflows.

### Structure
- Top nav or side nav
- Primary content zone
- Clear page title and supporting context
- One dominant pane, with secondary cards around it

### Rules
- Make hierarchy obvious in 3 seconds.
- Keep density controlled. Do not crowd every surface.
- Use cards and surface shifts to group information, not thick borders.
- Make the first screen answer: where am I, what can I do, what matters now?
- Prefer one strong primary panel over six equal panels.

### Must include
- Clear navigation state
- Empty state for first-use views
- Loading skeletons for async panels
- Responsive collapse behavior
- Keyboard-visible focus states

### Avoid
- Over-dashboarding with too many tiny cards
- Competing accents everywhere
- Floating, unanchored action buttons

## Browser extension / compact utility

### Job
Deliver a fast, obvious, narrow-width experience.

### Structure
- Compact header
- Main action area
- Supporting info in collapsible or clearly grouped blocks
- Footer utility actions only if necessary

### Rules
- Optimize for constrained width first.
- Keep all critical actions within the first viewport.
- Prefer short labels and strong hierarchy.
- Ensure keyboard navigation and focus order are clean.
- Make permission, connection, and error states explicit.

### Must include
- Zero-data state
- Permission or connection state, if relevant
- Error recovery path
- Loading state
- Compact asset set, including extension-safe icons if needed

### Avoid
- Desktop-page layouts squeezed into a narrow pane
- Tiny tap targets
- Hidden destructive actions

## Benchmark page / report / demo page

### Job
Make one proof land hard.

### Structure
1. One-line hook
2. Context in one short block
3. Main chart, table, or proof artifact
4. 2 to 4 supporting stats
5. Clear implication or CTA

### Rules
- One chart, one point.
- Make FAST visually dominant with restraint, not noise.
- Use labels generously. Never make the reader decode the chart.
- Prefer horizontal bars, ranked lists, direct comparisons, or code-before/after.
- Turn methodology into confidence, not clutter.

### Must include
- Headline that says why the proof matters
- Main proof asset above the fold
- Clear FAST highlight treatment
- Export-safe layout for screenshots or slides

### Avoid
- Pie charts
- Decorative charts without a point
- Dense paragraphs explaining obvious visuals

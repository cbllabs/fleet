# FAST Component Patterns

Production-tested patterns from the all-ramp deposit widget.

## Micro-polish Rules

These apply to every component, not just specific ones.

### Every pressable element needs `:active` scale feedback

```css
.pressable {
  transition: transform 160ms ease-out;
}
.pressable:active {
  transform: scale(0.97);
}
```

The scale should be 0.95–0.98. This gives immediate confirmation the interface heard the input. Apply to buttons, pills, quick-amount chips, segmented controls — anything the user clicks or taps.

### Popovers scale from their trigger; modals stay centered

Popovers feel wrong when they expand from center — they appear to come from nowhere rather than from where the user clicked.

```css
/* Radix UI */
.popover-content {
  transform-origin: var(--radix-popover-content-transform-origin);
}

/* Base UI */
.popover-content {
  transform-origin: var(--transform-origin);
}
```

**Exception:** Modals keep `transform-origin: center` — they are not anchored to a trigger and appear centered in the viewport by design.

### Use blur to bridge imperfect crossfades

When two states swap and the transition looks like two overlapping objects rather than one smooth change, add a brief blur during the transition.

```css
.button-label {
  transition: filter 200ms ease-out, opacity 200ms ease-out;
}
.button-label.is-transitioning {
  filter: blur(2px);
  opacity: 0.7;
}
```

Keep blur under 20px. Heavy blur is expensive in Safari.

### Tooltips: instant open after the first one

The first tooltip in a group should delay (prevents accidental activation). Once one is open, adjacent tooltips should open instantly with no animation.

```css
.tooltip {
  transition: transform 125ms ease-out, opacity 125ms ease-out;
  transform-origin: var(--transform-origin, center);
}

.tooltip[data-starting-style],
.tooltip[data-ending-style] {
  opacity: 0;
  transform: scale(0.97);
}

/* Skip animation once one tooltip in the group is already open */
.tooltip[data-instant] {
  transition-duration: 0ms;
}
```

### Never animate from scale(0)

Nothing in the real world appears from a single point. Elements entering from `scale(0)` look like they come out of nowhere. Start from `scale(0.95)` minimum, combined with `opacity: 0`.

```css
/* Wrong */
.entering { transform: scale(0); opacity: 0; }

/* Right */
.entering { transform: scale(0.95); opacity: 0; }
```

### Gate hover animations on pointer devices

Touch devices fire `:hover` on tap, causing hover animations to stick after touch. Wrap hover transforms in a media query.

```css
@media (hover: hover) and (pointer: fine) {
  .card:hover {
    transform: translateY(-2px);
  }
}
```

### Tint shadows to the background hue

Never use plain `rgba(0,0,0,x)` shadows on FAST surfaces. Shadows should carry the background hue — on Platinum canvas, shadows should read as cool blue-gray, not black fog.

```css
/* Wrong — pure black fog */
box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);

/* Right — hue-tinted to Platinum canvas */
box-shadow: 0 4px 16px rgba(120, 140, 180, 0.12);

/* FAST card shadow token already set correctly */
box-shadow: var(--shadow-card); /* uses the pre-tinted token */
```

Always use the FAST shadow tokens. Only write custom shadows if the token doesn't fit.

### Tabular nums for financial data

All numbers that sit in columns, change value, or need visual alignment should use tabular figures so digits don't shift width between values.

```css
.amount, .balance, .metric, [data-numeric] {
  font-variant-numeric: tabular-nums;
}
```

```tsx
<span className="tabular-nums">{formatted}</span>
```

Apply to: balances, amounts, rates, percentages, timestamps, transaction IDs, step counts.

---

## Premium Surface Patterns

### Double-Bezel Container

For premium moments — investor-facing stat blocks, hero proof cards, key feature callouts. Creates a "machined hardware" feel: like a glass plate sitting in an aluminum tray.

```tsx
{/* Outer shell — the tray */}
<div className="bg-fast-canvas/60 border border-fast-border/20 p-1.5 rounded-[2rem]">
  {/* Inner core — the glass plate */}
  <div className="bg-fast-card shadow-[inset_0_1px_1px_rgba(255,255,255,0.6)] rounded-[calc(2rem-0.375rem)] p-6 sm:p-8">
    {children}
  </div>
</div>
```

Key details:
- Outer shell: subtle background, hairline border, generous padding (`p-1.5`), large radius
- Inner core: own background, inner highlight shadow, radius mathematically smaller (`calc(2rem - 0.375rem)`) for concentric curves
- Do not use on every card — reserve for 1-2 premium containers per page

### Eyebrow Tag

A small pill badge placed above a major headline to establish context before the big type.

```tsx
<div className="flex flex-col gap-3">
  <span className="inline-flex w-fit items-center px-3 py-1 rounded-full
    bg-fast-pill-bg text-fast-text-muted text-[11px] font-medium
    uppercase tracking-[0.12em]">
    New
  </span>
  <h1 className="text-4xl md:text-6xl font-medium tracking-tight leading-none">
    Settle in 100ms
  </h1>
</div>
```

Keep the text short (1-3 words). Use for: new feature callouts, section labels, proof categories ("Speed", "Security", "Reach").

### Faux-OS Window Chrome

Wrap software mockups in a minimal macOS-style container so they read as "running application" not "screenshot pasted on background."

```tsx
<div className="rounded-xl border border-fast-border/30 overflow-hidden shadow-[var(--shadow-card)]">
  {/* Title bar */}
  <div className="h-9 bg-fast-canvas border-b border-fast-border/20 flex items-center px-3 gap-1.5">
    <div className="w-2.5 h-2.5 rounded-full bg-fast-border/60" />
    <div className="w-2.5 h-2.5 rounded-full bg-fast-border/60" />
    <div className="w-2.5 h-2.5 rounded-full bg-fast-border/60" />
  </div>
  {/* Content */}
  <div className="bg-fast-card">
    {children}
  </div>
</div>
```

---

## Card Container

```tsx
<div className="bg-fast-card rounded-card shadow-[var(--shadow-card)] border border-fast-border/30 p-5 sm:p-7 animate-scale-in">
  {children}
</div>
```

## Text Input

```tsx
<div>
  <label className="text-xs text-fast-text-muted mb-1 block">Label</label>
  <div className="relative">
    <input
      type="text"
      placeholder="Placeholder"
      className="w-full bg-fast-canvas rounded-xl px-4 py-3 text-sm font-medium
        text-fast-text-primary placeholder:text-fast-text-muted/40 outline-none
        border border-transparent focus:border-fast-border-focus focus:bg-white
        shadow-[var(--shadow-input-inner)] transition-colors duration-200"
    />
    {/* Optional right-side pill */}
    <span className="absolute right-4 top-1/2 -translate-y-1/2 bg-fast-pill-bg
      text-fast-text-muted text-xs font-medium px-2.5 py-1 rounded-full">
      USDC
    </span>
  </div>
  {error && <p className="text-xs text-fast-error mt-1 px-1">{error}</p>}
</div>
```

## Large Number Input (amount)

```tsx
<input
  type="text"
  inputMode="decimal"
  placeholder="0.00"
  className="w-full bg-fast-canvas rounded-xl px-4 py-3 text-2xl font-medium
    text-fast-text-primary placeholder:text-fast-text-muted/40 outline-none
    border border-transparent focus:border-fast-border-focus focus:bg-white
    shadow-[var(--shadow-input-inner)] transition-colors duration-200"
/>
```

## Quick Amount Buttons

```tsx
<div className="flex items-center gap-1.5 mt-2">
  {amounts.map(amt => (
    <button
      key={amt}
      onClick={() => onChange(amt)}
      className={selected === amt
        ? 'px-3 py-1 rounded-full text-xs font-medium bg-fast-charcoal text-white'
        : 'px-3 py-1 rounded-full text-xs font-medium bg-fast-pill-bg text-fast-text-muted hover:bg-fast-charcoal/10'
      }
    >
      ${amt}
    </button>
  ))}
</div>
```

## Segmented Control (e.g., chain selector)

```tsx
<div className="bg-fast-canvas rounded-xl p-1 flex gap-1" role="group" aria-label="Options">
  {options.map(opt => (
    <button
      key={opt.id}
      onClick={() => onSelect(opt.id)}
      aria-pressed={opt.id === selected}
      className={`flex-1 min-h-[44px] py-2 px-3 rounded-[10px] flex items-center gap-2
        transition-all duration-200 ${
          opt.id === selected
            ? 'bg-white text-fast-charcoal shadow-sm'
            : 'text-fast-text-muted hover:text-fast-text-primary'
        }`}
    >
      {opt.icon}
      <div className="flex flex-col items-start">
        <span className="text-sm font-medium">{opt.label}</span>
        <span className="text-[10px] text-fast-text-muted leading-tight">{opt.sublabel}</span>
      </div>
    </button>
  ))}
</div>
```

## Primary Action Button

```tsx
<button
  onClick={onClick}
  disabled={disabled || loading}
  className="w-full py-3.5 rounded-full bg-fast-charcoal text-[#F6F8FA] text-base
    font-medium tracking-[-0.48px] leading-[92%] transition-all duration-300
    shadow-[0_1px_1px_0_rgba(0,0,0,0.10)]
    hover:shadow-[0_2px_4px_0_rgba(0,0,0,0.15)] hover:bg-fast-charcoal/90
    active:scale-[0.98] disabled:opacity-40 disabled:shadow-none disabled:cursor-not-allowed"
>
  {loading && (
    <span className="inline-block w-4 h-4 border-2 border-white/20 border-t-white
      rounded-full animate-spin mr-2 align-middle" />
  )}
  {label}
</button>
```

## Step Indicator (multi-step flow)

```tsx
<div className="flex items-center justify-center gap-1.5">
  <div className={`w-1.5 h-1.5 rounded-full ${step >= 1 ? 'bg-fast-charcoal' : 'bg-fast-border'}`} />
  <div className={`w-1.5 h-1.5 rounded-full ${step >= 2 ? 'bg-fast-charcoal' : 'bg-fast-border'}`} />
  <span className="text-xs text-fast-text-muted ml-1">Step {step} of 2</span>
</div>
```

## Error Banner (with retry)

```tsx
<div className="text-sm text-fast-error bg-fast-error/5 border border-fast-error/10
  rounded-xl px-4 py-3 animate-fade-in-up flex items-center justify-between gap-2">
  <div>{message}</div>
  <button
    onClick={onRetry}
    className="shrink-0 text-xs font-medium text-fast-charcoal bg-fast-canvas
      hover:bg-fast-charcoal/5 rounded-full px-3 py-1.5 transition-colors"
  >
    Try again
  </button>
</div>
```

## Info Summary Bar

```tsx
<p className="text-xs text-fast-text-muted bg-fast-surface rounded-lg px-3 py-2">
  Summary text here
</p>
```

## Balance / Metadata Display

```tsx
<div className="text-xs text-fast-text-muted">
  {isLoading ? (
    <div className="h-3 w-24 rounded animate-shimmer" />
  ) : (
    <>Balance: {formatted} USDC</>
  )}
</div>
```

## Nav Bar

```tsx
<nav className="fixed top-0 left-0 right-0 h-14 flex items-center justify-between px-6 z-10
  bg-fast-canvas/80 backdrop-blur-md border-b border-fast-border/50">
  <Image src="/fast-logo.svg" alt="FAST" width={80} height={28} priority />
  <div>{/* Right-side action (wallet button, CTA, etc.) */}</div>
</nav>
```

## Link Text (inline)

```tsx
<a href={url} target="_blank" rel="noopener noreferrer"
  className="text-fast-charcoal hover:underline">
  {label}
</a>
```

## Pill / Badge

```tsx
<span className="bg-fast-pill-bg text-fast-text-muted text-xs font-medium px-2.5 py-1 rounded-full">
  USDC
</span>
```

## Comparison Table (data slides only)

```css
/* FAST column: dark charcoal bg, white text */
.fast-column { background: #2B2C2F; color: #F7F8FA; }
/* FAST row highlight */
.fast-row { background: #C5CEE8; }
/* Competitor columns: white/light gray */
.competitor-column { background: #FFFFFF; }
/* Header row */
.table-header { background: #4A4D52; color: #F7F8FA; }
```

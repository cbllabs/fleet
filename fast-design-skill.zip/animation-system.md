# FAST Animation System

## Animation Decision Framework

Answer these four questions before writing any animation code.

### 1. Should this animate at all?

How often will a user see this motion?

| Frequency | Decision |
|---|---|
| 100+ times/day (keyboard shortcuts, command palette) | No animation. Ever. |
| Tens of times/day (hover states, list navigation) | Remove or drastically reduce |
| Occasional (modals, drawers, toasts) | Standard animation |
| Rare / first-time (onboarding, celebrations) | Full delight is fine |

**Never animate keyboard-initiated actions.** These fire hundreds of times daily. Animation makes them feel slow and disconnected from input.

### 2. What is the purpose?

Every animation must answer "why does this animate?" Valid answers:

- **Spatial consistency** — toast enters and exits from the same edge, making swipe-to-dismiss feel intuitive
- **State indication** — a morphing button shows the transition is happening
- **Feedback** — button scales down on press, confirming the interface heard the user
- **Preventing jarring changes** — elements appearing without any transition look broken

If the only answer is "it looks cool" and the user sees it often, cut it.

### 3. What easing?

```
Is the element entering or exiting?
  Yes → ease-out (starts fast, feels instant)
  No →
    Is it moving across the screen?
      Yes → ease-in-out (natural arc)
    Is it a hover or color change?
      Yes → ease
    Is it constant motion (shimmer, spinner)?
      Yes → linear
    Default → ease-out
```

**Never use ease-in on UI elements.** It starts slow — the exact moment the user is watching most closely. A 300ms ease-in *feels* slower than a 300ms ease-out at identical actual duration.

**Use custom easing curves.** Built-in CSS easings are too weak. Use the FAST easing set below or find stronger variants at [easing.dev](https://easing.dev/).

### 4. How fast?

| Element | Duration |
|---|---|
| Button press feedback | 100–160ms |
| Tooltips, small popovers | 125–200ms |
| Dropdowns, selects | 150–250ms |
| Modals, drawers | 200–400ms |
| Marketing / scroll reveals | 500–700ms |

**UI animations should stay under 300ms.** A 180ms dropdown feels more responsive than a 400ms one. Perceived speed matters as much as actual speed — ease-out at 200ms *feels* faster than ease-in at 200ms because the user sees immediate movement.

---

## FAST Easing Presets

```css
:root {
  /* UI interactions: entering, exiting, expanding */
  --ease-out: cubic-bezier(0.23, 1, 0.32, 1);

  /* On-screen movement: dragging, position shifts */
  --ease-in-out: cubic-bezier(0.77, 0, 0.175, 1);

  /* Static demos / marketing reveals (more dramatic) */
  --ease-demo: cubic-bezier(0.16, 1, 0.3, 1);

  /* Drawer / sheet entry (iOS-like) */
  --ease-drawer: cubic-bezier(0.32, 0.72, 0, 1);
}
```

Default to `--ease-out` for anything entering, exiting, or responding to input.

---

## Asymmetric Timing

Entering should feel deliberate; exiting should feel instant.

```css
/* Hold-to-confirm: slow fill while user decides */
.button:active .overlay {
  transition: clip-path 2s linear;
}

/* Release: instant snap back */
.overlay {
  transition: clip-path 200ms ease-out;
}
```

Apply this broadly: slow where the user is deciding, fast where the system is responding.

---

## Transitions vs. Keyframes

**Use CSS transitions for dynamic, frequently-triggered, or interruptible UI.** Transitions can be retargeted mid-animation. Keyframes restart from zero on interruption — adding a second toast while the first is entering looks wrong.

```css
/* Interruptible — right for toasts, drawers, dropdowns */
.toast {
  transition: transform 400ms var(--ease-out), opacity 400ms var(--ease-out);
}

/* Not interruptible — only for one-shot decorative animation */
@keyframes breathe {
  0%, 100% { opacity: 0.4; transform: scale(0.98); }
  50%       { opacity: 1;   transform: scale(1); }
}
```

---

## Production Keyframes

```css
/* Primary entrance — form fields, content blocks */
@keyframes fade-in-up {
  from { opacity: 0; transform: translateY(8px); }
  to   { opacity: 1; transform: translateY(0); }
}

/* Card/container entrance */
@keyframes scale-in {
  from { opacity: 0; transform: scale(0.96); }
  to   { opacity: 1; transform: scale(1); }
}

/* Horizontal slide (status items, list items) */
@keyframes slide-in-right {
  from { opacity: 0; transform: translateX(12px); }
  to   { opacity: 1; transform: translateX(0); }
}

/* Status indicator pulse */
@keyframes pulse-dot {
  0%, 100% { opacity: 1;   transform: scale(1); }
  50%       { opacity: 0.5; transform: scale(0.85); }
}

/* Loading placeholder */
@keyframes shimmer {
  0%   { background-position: -200% 0; }
  100% { background-position:  200% 0; }
}

/* Loading screen logo */
@keyframes breathe {
  0%, 100% { opacity: 0.4; transform: scale(0.98); }
  50%       { opacity: 1;   transform: scale(1); }
}

/* Loading dots */
@keyframes bounce-dot {
  0%, 80%, 100% { opacity: 0.3; transform: translateY(0); }
  40%           { opacity: 1;   transform: translateY(-4px); }
}
```

## Utility Classes

```css
.animate-fade-in-up {
  animation: fade-in-up 0.4s var(--ease-out, ease-out) both;
  animation-delay: calc(var(--stagger, 0) * 80ms);
}

.animate-scale-in {
  animation: scale-in 0.35s var(--ease-out, ease-out) both;
}

.animate-slide-in-right {
  animation: slide-in-right 0.4s var(--ease-out, ease-out) both;
  animation-delay: calc(var(--stagger, 0) * 80ms);
}

.animate-pulse-dot {
  animation: pulse-dot 1.5s ease-in-out infinite;
}

/* Shimmer skeleton — Platinum canvas with near-white peak highlight */
.animate-shimmer {
  background: linear-gradient(90deg,
    rgba(200,207,216,0.18) 25%,
    rgba(255,255,255,0.80) 50%,
    rgba(200,207,216,0.18) 75%);
  background-size: 200% 100%;
  animation: shimmer 1.5s linear infinite;
}

.animate-breathe {
  animation: breathe 2s ease-in-out infinite;
}

.animate-bounce-dot {
  animation: bounce-dot 1.2s ease-in-out infinite;
}
```

## Stagger Pattern

```tsx
{items.map((item, i) => (
  <div
    key={item.id}
    className="animate-fade-in-up"
    style={{ '--stagger': i } as React.CSSProperties}
  >
    {item.content}
  </div>
))}
```

Keep stagger delay short (30–80ms between items). Cap at 5 items — beyond that it looks slow, not polished. Never block interaction while stagger plays.

## When to Use What

| Context | Animation | Duration |
|---|---|---|
| Card mounting | `scale-in` | 350ms |
| Form field stagger | `fade-in-up` | 400ms + 80ms×index |
| Status step appearing | `slide-in-right` | 400ms + 80ms×index |
| Error banner | `fade-in-up` | 400ms |
| Active status dot | `pulse-dot` | 1.5s loop |
| Data loading placeholder | `shimmer` | 1.5s loop |
| Button loading | border spinner | spin |
| Button press | `active:scale-[0.98]` | instant |
| Content swap | `scale-in` | 350ms |
| Page/loading screen | `breathe` | 2s loop |

---

## Modern Entry: @starting-style

The CSS-only way to animate element entry without a mounted state flag. Replaces the `useEffect → setMounted(true)` pattern.

```css
.toast {
  opacity: 1;
  transform: translateY(0);
  transition: opacity 400ms var(--ease-out), transform 400ms var(--ease-out);

  @starting-style {
    opacity: 0;
    transform: translateY(100%);
  }
}
```

Browser support: Chrome 117+, Safari 17.5+, Firefox 129+. Fall back to the `data-mounted` attribute pattern for broader support:

```tsx
// Legacy fallback (works everywhere)
useEffect(() => { setMounted(true); }, []);
// <div data-mounted={mounted}>
```

---

## Perceived Performance

Animation speed affects how fast the *whole app* feels, not just the component animating.

- A fast-spinning spinner makes loading feel faster (same load time, different perception)
- A 180ms dropdown animation feels more responsive than a 400ms one
- Instant tooltip open (after the first) makes an entire toolbar feel snappier

Don't only optimize actual performance. Optimize what users perceive.

---

## Performance Rules

1. **Only animate:** `transform`, `opacity`, `filter`, `clip-path` — GPU-composited, no layout recalc
2. **Never animate:** `width`, `height`, `top`, `left`, `margin`, `padding` — triggers full paint cycle
3. **Framer Motion shorthand is NOT hardware-accelerated.** `animate={{ x: 100 }}` uses `requestAnimationFrame` on the main thread. Use `animate={{ transform: "translateX(100px)" }}` instead when frame drops matter.
4. **Don't update CSS variables on containers with many children.** Changing `--swipe-amount` on a parent recalculates styles for every child. Set `transform` directly on the element.

```js
// Bad: triggers style recalc on all children
element.style.setProperty('--offset', `${distance}px`);

// Good: only affects this element
element.style.transform = `translateY(${distance}px)`;
```

5. **CSS animations beat JS under load.** CSS runs off the main thread. Framer Motion `requestAnimationFrame` animations drop frames when the browser is simultaneously loading content or running scripts. Use CSS for predetermined animations; JS for dynamic or interruptible ones.

---

## Scroll Reveal (landing pages only — not widgets)

```javascript
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.1 });

document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
```

```css
.reveal {
  opacity: 0;
  transform: translateY(20px);
  transition: opacity 0.6s var(--ease-demo), transform 0.6s var(--ease-demo);
}
.reveal.visible {
  opacity: 1;
  transform: translateY(0);
}
```

## Reduced Motion

Always include:

```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }
}
```

Liquid Metal Tier 1 handles `prefers-reduced-motion` automatically in JS. Tier 2 respects it in `liquid-metal.css`.

---

## Chrome Liquid Metal Gradient (CSS-only hero, no Tier 1 available)

```css
.gradient-liquid-metal {
  background: linear-gradient(261deg,
    #F6F8FA -8%,
    #C8CFD8 22%,
    #A1B0CF 48%,
    #C8CFD8 72%,
    #5F6672 108%);
}
```

Only for hero/feature sections. Never on data-heavy slides or forms.

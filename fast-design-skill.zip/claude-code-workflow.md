# Claude Code Workflow for FAST UI

Use this when Claude Code or another coding agent is building the interface.

## Goal

Turn the FAST Demo Kit from passive guidance into an implementation routine that produces polished output fast.

## Before coding

State these explicitly:
- chosen surface
- target user action or target insight
- primary CTA or primary proof block
- references you are loading
- assets you expect to create or wire

Good example:
`Surface: widget. Goal: let users deposit into FAST in one obvious flow. Primary CTA: Deposit to FAST. Refs: design-tokens, ux-principles, surface-recipes, component-patterns, pre-ship-checklist. Assets: icon, OG image, metadata.`

## Implementation order

1. Set the page or screen structure.
2. Apply FAST tokens, type, and spacing.
3. Build the happy path.
4. Add loading, empty, error, and success states.
5. Add metadata, icon, OG, and other launch assets.
6. Do responsive cleanup.
7. Do final visual cleanup.

## Default coding behavior

- Prefer adapting the bundled starter assets over writing generic scaffolding from scratch.
- Keep one primary action per screen.
- Use real labels and CTA copy early.
- Do not leave placeholders for launch assets if the task is meant to feel complete.
- Do not declare done while obvious states are missing.

## Completion report format

Use this structure when reporting back:

### Built
- surface
- main flow or page sections

### FAST alignment
- references used
- any deliberate deviations

### Ship polish
- icon or favicon
- OG/Twitter image
- metadata
- loading/empty/error/success states
- responsive pass

### Remaining gaps
- only list real unresolved items

## Escalate when needed

- If the page needs custom visual concepts, route to `creative-direction`.
- If screenshots or a live preview exist, route to `visual-qa` before final sign-off.
- If the task becomes payment or SDK integration work, route to `fast-skill`.

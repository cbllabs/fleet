import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'FAST Demo Title',
  description: 'Short, concrete description of what this FAST page or product does.',
  openGraph: {
    title: 'FAST Demo Title',
    description: 'Short, concrete description of what this FAST page or product does.',
    images: ['/opengraph-image.jpg'],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'FAST Demo Title',
    description: 'Short, concrete description of what this FAST page or product does.',
    images: ['/twitter-image.jpg'],
  },
}

/*
Expected companion assets for App Router projects:
- app/icon.png
- app/opengraph-image.jpg or .png
- app/twitter-image.jpg or .png if separate from OG
*/

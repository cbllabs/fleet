# FAST Copy Guidelines

## Headlines

- Under 10 words
- Benefit-driven, not feature-driven
- Specific numbers beat vague claims
- "100ms settlement" not "blazing fast"
- "14/14 models pass" not "industry-leading compatibility"
- Sentence case, not Title Case On Every Word
- Use `text-wrap: balance` in CSS to prevent single-word orphans

## Body Copy

- Short paragraphs (1-3 sentences)
- 6th-8th grade reading level
- Active voice: "We couldn't save your changes" not "Mistakes were made"
- No jargon without explanation
- Every sentence earns its place
- No exclamation marks — be confident, not loud

## CTAs

- Specific and action-oriented
- "Start building" not "Get started"
- "See the benchmark" not "Learn more"
- "Try the demo" not "Click here"

## Error and Status Messages

- **Errors:** Name the problem, give a recovery path. "Connection failed. Try again." — not "Oops! Something went wrong."
- **Success:** Calm and certain. "Payment sent." — not "Payment sent!"
- **Empty states:** Tell the user what to do next, not just that nothing is there.

## Numbers and Data

- Use organic, realistic values — not round placeholders
  - `47.2%` not `50%`
  - `$99.00` not `$100`
  - `1,847 transactions` not `2,000 transactions`
  - `+1 (312) 847-1928` not `555-1234`
- Label numbers clearly: "47.2% faster settlement" not just "47.2%"
- Use real-looking names for placeholder users: not "John Doe", "Jane Smith", or "User 1"

## The FAST Voice

- **Confident:** "The only protocol that..." (backed by data)
- **Technical:** "150K TPS on commodity hardware" (engineers respect specifics)
- **Concise:** Cut every word that doesn't earn its place
- **Never arrogant:** Let the data speak. Don't say "we're the best" — show it.
- **Calm:** No chest-thumping, no hype. Sound like the infrastructure layer, not a startup pitch.

## Forbidden Words (in user-facing content)

### Crypto/web3 jargon
- "bridge" (use "deposit" or "transfer")
- "blockchain", "wallets", "gas", "crypto" (in user-facing contexts)
- "Web3" (say "AI agent economy" or "programmable payments")
- ALL CAPS labels outside pitch decks (use sentence case in product UI)

### AI copywriting clichés — banned entirely
These are the most common signals that copy was generated without taste:

- "Elevate" / "Elevating"
- "Seamless" / "Seamlessly"
- "Unleash"
- "Next-Gen" / "Next-Generation"
- "Game-changer" / "Game-changing"
- "Revolutionize" / "Revolutionary"
- "Delve"
- "Streamline" / "Streamlined"
- "Empower" / "Empowering"
- "Leverage" (as a verb)
- "Robust"
- "Cutting-edge"
- "State-of-the-art"
- "In today's world" / "In the world of..."
- "Tapestry"
- "Synergy"
- "blazing fast", "lightning fast" (use a real number instead)

Replace with concrete verbs and specific claims. If the sentence still works after removing the word, the word was filler.

# Liquid Metal — FAST's brand visual

Mercury-like chrome flow. The only decorative element in FAST's product UI.
Three tiers, one shared visual language.

---

## The three tiers

| Tier | How it renders                           | When to use                             |
|------|------------------------------------------|-----------------------------------------|
| 1    | Real-time WebGL shader (Three.js)        | Hero sections, feature anchors, brand moments |
| 2    | CSS-only animated fallback               | No-JS pages, emails, low-power devices, print preview |
| 3    | Flat chrome-sheen utilities              | Pills, buttons, chrome-text, small UI   |

Tier 1 and Tier 2 use a **dark graphite → highlight** palette (poster scale).
Tier 3 uses a **light silver** palette (small UI). This is intentional and
canonical.

---

## Tier 1 — WebGL shader

### Load

```html
<!-- Three.js is the only dependency for Tier 1. -->
<script src="https://unpkg.com/three@0.160.0/build/three.min.js"></script>
<script src="assets/liquid-metal.js"></script>
```

### Attach — declarative

Any element with a `data-fast-liquid-metal` attribute is auto-attached on
`DOMContentLoaded`:

```html
<div data-fast-liquid-metal="hero"    style="height: 520px;"></div>
<div data-fast-liquid-metal="ambient" style="height: 320px;"></div>
<div data-fast-liquid-metal="spark"   style="height: 120px; width: 120px;"></div>
<div data-fast-liquid-metal="still"   style="height: 260px;"></div>
```

### Attach — imperative

```js
const lm = FastLiquidMetal.attach(element, { preset: 'ambient' });

// At any time:
lm.setPreset('hero');        // swap preset
lm.setUniform('contrast', 1.3); // tweak one value (advanced)
lm.destroy();                // cleans up WebGL context + rAF
```

### Presets

| Preset    | Speed | Scale | Warp | Noise | Intent                                        |
|-----------|-------|-------|------|-------|-----------------------------------------------|
| `hero`    | 0.28  | 1.35  | 1.2  | 0.04  | Cinematic flow. Landing hero, section anchors |
| `ambient` | 0.08  | 2.10  | 0.75 | 0.02  | Slow drift behind calm typography             |
| `spark`   | 0.45  | 0.90  | 1.5  | 0.03  | Punchy, tight — loading / empty state accents |
| `still`   | 0.00  | 1.35  | 1.0  | 0.03  | Frozen poster frame — tables, forms, print    |

All presets share the same palette, sheen band, and atmospheric base. They
only differ in speed / scale / warp / contrast.

Access preset definitions at runtime: `FastLiquidMetal.PRESETS`.

### Pointer reactivity

`hero` and (lightly) `ambient` respond to pointer movement —  the shader
warps *toward* the cursor, giving the surface a sense of wet tension.
`spark` and `still` ignore pointer (spark is too small; still is static).

### Performance safeguards built in

The library does these automatically:

- **Pauses when off-screen** (IntersectionObserver). Scrolled-away canvases
  stop their rAF loop.
- **Freezes under `prefers-reduced-motion`** — renders one frame at a chosen
  static offset, then stops.
- **Caps devicePixelRatio** at 1.75 to protect retina iPads.
- **Auto-cleans** on `destroy()` — removes canvas, disposes geometry, kills rAF.

You do not need to handle any of this.

---

## Tier 2 — CSS fallback

Pure CSS, no JS, no dependencies. Still animated via `background-position`
orbit + a specular ribbon pseudo-element.

```html
<link rel="stylesheet" href="assets/liquid-metal.css">
<div class="fast-liquid-metal-css" style="height: 240px;"></div>
```

### Masks (blend into canvas)

```html
<div class="fast-liquid-metal-css fast-liquid-metal-fade-bottom"></div>
<div class="fast-liquid-metal-css fast-liquid-metal-fade-top"></div>
<div class="fast-liquid-metal-css fast-liquid-metal-fade-radial"></div>
```

Use `fade-bottom` when the metal is behind an element and you want it to
dissolve into the page below. `fade-radial` is ideal for card backgrounds.

### Reduced motion

Animations freeze automatically under `prefers-reduced-motion: reduce`.

---

## Tier 3 — chrome-sheen utilities

Flat silver chrome for small UI. Palette:
`#F6F8FA · #C8CFD8 · #E3E5EA · #F6F8FA · #DEE3E8 · #5F6672` @ 261°.

```html
<!-- Static chrome pill -->
<span class="fast-chrome-sheen" style="padding: 8px 16px; border-radius: 9999px;">
  Install Fast wallet
</span>

<!-- Animated chrome pill (slow orbit, ~10s) -->
<span class="fast-chrome-sheen fast-chrome-sheen--flowing">Animated</span>

<!-- Chrome-filled text (for hero wordmarks, numerals) -->
<h1 class="fast-chrome-text fast-chrome-text--flowing">Payments for agents.</h1>
```

### CSS variables (customizable, but don't)

```css
:root {
  --fast-chrome-1: #F6F8FA;
  --fast-chrome-2: #C8CFD8;
  --fast-chrome-3: #E3E5EA;
  --fast-chrome-4: #F6F8FA;
  --fast-chrome-5: #DEE3E8;
  --fast-chrome-6: #5F6672;
  --fast-chrome-angle: 261deg;
}
```

The palette is locked. Don't override unless you have a very specific reason.

---

## Composition recipes

### Hero = Tier 1 shader + Tier 3 chrome-sheen CTA

```html
<section style="position: relative; height: 600px; border-radius: 28px; overflow: hidden;">
  <div data-fast-liquid-metal="hero" style="position: absolute; inset: 0;"></div>
  <div style="position: relative; z-index: 1; padding: 80px; color: #F6F8FA;">
    <h1 style="font-size: 88px; font-weight: 500; letter-spacing: -0.04em;">
      Payments<br/>for agents
    </h1>
    <a href="#" class="fast-chrome-sheen"
       style="display: inline-block; margin-top: 32px; padding: 12px 24px;
              border-radius: 9999px; color: #2B2C2F; text-decoration: none;">
      Start building
    </a>
  </div>
</section>
```

### Card wash = Tier 1 ambient + radial mask

```html
<div style="position: relative; background: #FFF; border-radius: 14px;
            padding: 40px; overflow: hidden;">
  <div data-fast-liquid-metal="ambient"
       class="fast-liquid-metal-fade-radial"
       style="position: absolute; inset: 0; opacity: 0.35;"></div>
  <div style="position: relative; z-index: 1;">
    <h2>Section intro</h2>
    <p>Typography reads clearly on top of ambient drift.</p>
  </div>
</div>
```

### Loading state = Tier 1 spark

```html
<div style="display: grid; place-items: center; height: 200px;">
  <div data-fast-liquid-metal="spark"
       style="width: 72px; height: 72px; border-radius: 50%;"></div>
  <p style="margin-top: 16px; font-size: 12px; color: #5F6672;">
    Confirming deposit…
  </p>
</div>
```

A 72×72px spark orb is easier on the eye than a spinner and sells the
"mercury moves for you" concept.

### Chrome wordmark = Tier 3 chrome-text

```html
<h1 class="fast-chrome-text fast-chrome-text--flowing"
    style="font-size: 120px; font-weight: 500; letter-spacing: -0.04em;">
  Payments for agents.
</h1>
```

---

## When to use which tier

| Context                                 | Pick                                         |
|-----------------------------------------|----------------------------------------------|
| Landing hero, section divider           | Tier 1 `hero`                                |
| Card / section background wash          | Tier 1 `ambient` + `fade-radial`             |
| Loading state, empty state, icon orb    | Tier 1 `spark`                               |
| Tables / forms / print / motion-off     | Tier 1 `still` or skip altogether            |
| Email / no-JS / low-power device        | Tier 2 CSS fallback                          |
| Pill, badge, chip, button, wordmark     | Tier 3 chrome-sheen / chrome-text            |
| Heading numeral highlights              | Tier 3 chrome-text                           |

---

## Accessibility

- Shader freezes under `prefers-reduced-motion`.
- Tier 2 animations freeze under the same media query.
- Text overlaid on Tier 1 must meet WCAG AA — the surface is dark graphite
  with highlights, so `#F6F8FA` / `#FFFFFF` text passes, but darker text does
  not. Use light text on the shader.
- Never rely on Liquid Metal to convey information. It's atmosphere, not UI.

---

## Do & don't

### Do

- Reach for `hero` on full-bleed landing sections where brand mood is the job.
- Use `ambient` behind calm typography — stats, quotes, section intros.
- Let `spark` stand in for spinners on deposit/loading states.
- Apply `fade-bottom` or `fade-radial` masks to blend into the page canvas.
- Compose tiers: hero WebGL + chrome-sheen CTAs read as one system.

### Don't

- Use `hero` or `spark` behind active inputs, tables, or long reading copy.
- Tint it. The palette is locked. Colored liquid metal is a different brand.
- Stack two Tier 1 instances on one screen. One centerpiece per view.
- Put chrome-text on chrome backgrounds — it disappears.
- Add drop shadows to the shader canvas — it kills the metallic read.

---

## Browser support

- **Tier 1:** any browser with WebGL 1 (~97% of web). Falls back gracefully
  to no-shader if Three.js fails to load — canvas stays blank, rest of the
  page works.
- **Tier 2:** any browser that supports CSS gradients + `background-position`
  animation (~100% of modern browsers).
- **Tier 3:** universal. Works in every browser including print.

---

## Palette reference

### Liquid Metal shader (Tier 1, Tier 2 — dark graphite)

| Stop | Hex       | Role                      |
|------|-----------|---------------------------|
| 1    | `#0E1013` | Near-black (deep shadow)  |
| 2    | `#333841` | Graphite (body)           |
| 3    | `#8F99A8` | Pewter (mid)              |
| 4    | `#DEE6F0` | Highlight (specular)      |
| 5    | `#1C2026` | Deep shadow (creases)     |
| 6    | `#B3BECC` | Soft silver (fill)        |

### Chrome sheen (Tier 3 — light silver)

| Stop | Hex       | Role                  |
|------|-----------|-----------------------|
| 1    | `#F6F8FA` | Highlight             |
| 2    | `#C8CFD8` | Cool mid              |
| 3    | `#E3E5EA` | Warm mid              |
| 4    | `#F6F8FA` | Peak highlight        |
| 5    | `#DEE3E8` | Soft                  |
| 6    | `#5F6672` | Shadow                |

Gradient direction: **261°** (canonical FAST chrome angle).
